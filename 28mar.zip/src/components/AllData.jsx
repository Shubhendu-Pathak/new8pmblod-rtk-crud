import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { showUser } from '../store-rtk/thunk/fetchUsers'
import Button from 'react-bootstrap/Button';

function AllData() {

    let {isLoading,data,error} = useSelector(state=>state.usersData)
    // console.log(userdata);

let dispatch = useDispatch()

useEffect(()=>{
dispatch(showUser())
},[])

  return (
    <div>
        <h1>AllData</h1>

{
    data && data.map(ele=>(
        <div className='border border-2  p-3 my-3 w-50 m-auto rounded-4 ' key={ele.id}>
            <img className='d-block m-auto mb-3' height='100px' src={ele?.image} alt="" />
            <p className='fst-italic fs-2 text-center' >{ele?.firstName} - {ele?.lastName}</p>
            <h3 className='fs-4 mt-3'>Email = {ele?.email}</h3>
            <div className="btns d-flex justify-content-evenly my-3">
            <Button variant="primary">Preview</Button>{' '}
            <Button variant="success">EDIT</Button>{' '}
            <Button variant="danger">Delete</Button>{' '}
            </div>
        </div>
    ))
}

    </div>
  )
}

export default AllData