import React from 'react'

function Create() {
  return (
    <div>Create</div>
  )
}

export default Create