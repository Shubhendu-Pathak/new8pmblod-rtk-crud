import { createSlice } from "@reduxjs/toolkit";
import { showUser } from "./thunk/fetchUsers";


const userSlice = createSlice({
    name:'users',
    initialState:{isLoading:false,data:null,error:null},
    extraReducers(builder){
        
// get 
builder.addCase(showUser.pending,(state,action)=>{
    state.isLoading = true
}),
builder.addCase(showUser.fulfilled,(state,action)=>{
    state.isLoading = false
    state.data = action.payload
}),
builder.addCase(showUser.rejected,(state,action)=>{
    state.isLoading = false
    state.error = action.error
})

    }
})

export const usersReducer = userSlice.reducer