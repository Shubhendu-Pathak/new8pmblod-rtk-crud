// below are  action for get post delete put

import { createAsyncThunk } from "@reduxjs/toolkit";

// get action

export const showUser = createAsyncThunk(
  "showUser",
  async (args, { rejectWithValue }) => {
    let response = await fetch(`http://localhost:4000/users`);

    try {
      let result = await response.json();
    //   console.log(result);
      return result;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
